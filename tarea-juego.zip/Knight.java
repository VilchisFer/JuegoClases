public class Knight extends Characters {

  public Knight (){
    wb = new SwordBehavior ();
  }

  public void display (){
    System.out.println ("I'm a knight");
  }
  
}