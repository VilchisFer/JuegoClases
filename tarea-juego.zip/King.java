public class King extends Characters {

  public King (){
    wb = new KnifeBehavior ();
  }

  public void display (){
    System.out.println ("I'm the king");
  }
  
}