public class Queen extends Characters {

  public Queen (){
    wb = new BowAndArrowBehavior ();
  }

  public void display (){
    System.out.println ("I´m the queen");
  }
  
}