public class AxeBehavior implements WeaponBehavior{
  public void fight (){
    System.out.println ("I can chopping with an axe");
  }
}