class Main {
  public static void main(String[] args) {
    System.out.println("Juego de accion");

    //Código para mostrar los 4 personajes del juego

    Characters queen, king, troll, knight;

    queen    = new Queen ();
    king    = new King ();
    troll  = new Troll ();
    knight  = new Knight ();


    //Esto debe llamar todos los println y mostrar lo que hace cada personaje
    queen.showCharacters ();
    king.showCharacters ();
    troll.showCharacters ();
    knight.showCharacters ();


  }
}