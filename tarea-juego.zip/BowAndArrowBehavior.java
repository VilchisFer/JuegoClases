public class BowAndArrowBehavior implements WeaponBehavior{
  public void fight (){
    System.out.println ("I can shooting an arrow with a bow");
  }
}