public class SwordBehavior implements WeaponBehavior{
  public void fight (){
    System.out.println ("I can shooting an arrow with a bow");
  }
}