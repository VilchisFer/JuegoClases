public abstract class Characters {

  WeaponBehavior wb;

  public abstract void display ();

  public void performWeapon (){
    wb.fight();
  }

  public void showCharacters (){
    display();
    performWeapon();
  }

  public void setWeaponBehavior (WeaponBehavior w){
    wb=w;
  }
}
