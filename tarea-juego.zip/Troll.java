public class Troll extends Characters {

  public Troll (){
    wb = new AxeBehavior ();
  }

  public void display (){
    System.out.println ("I'm a troll");
  }
  
}